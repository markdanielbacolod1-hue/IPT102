const express  = require('express');
const router   = express.Router();
const rateLimit = require('express-rate-limit');

const { login, logout, refreshToken, getMe } = require('../controllers/authController');
const { authenticate }   = require('../middleware/auth');
const { loginRules }     = require('../middleware/validators');

// Strict rate limit on login to prevent brute force
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max:      10,              // 10 attempts per window
  message:  { success: false, message: 'Too many login attempts. Please try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders:   false,
});

// POST /api/auth/login
router.post('/login', loginLimiter, loginRules, login);

// POST /api/auth/logout  (requires valid access token)
router.post('/logout', authenticate, logout);

// POST /api/auth/refresh  (uses refresh token cookie)
router.post('/refresh', refreshToken);

// GET  /api/auth/me  (returns current session user)
router.get('/me', authenticate, getMe);

module.exports = router;
