const jwt  = require('jsonwebtoken');
const pool = require('../config/db');

// ─── Verify Access Token ─────────────────────────────────────────────────────
const authenticate = async (req, res, next) => {
  try {
    // Support both Authorization header and httpOnly cookie
    let token = req.cookies?.accessToken;

    const authHeader = req.headers.authorization;
    if (!token && authHeader?.startsWith('Bearer ')) {
      token = authHeader.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({ success: false, message: 'Access token required.' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Fetch fresh user data to catch status/role changes mid-session
    const [rows] = await pool.query(
      `SELECT u.user_id, u.full_name, u.email, u.status,
              r.role_name, u.department_id
       FROM   users u
       JOIN   roles r ON u.role_id = r.role_id
       WHERE  u.user_id = ?`,
      [decoded.userId]
    );

    if (!rows.length) {
      return res.status(401).json({ success: false, message: 'User not found.' });
    }

    const user = rows[0];

    if (user.status !== 'Active') {
      return res.status(403).json({ success: false, message: 'Account is inactive.' });
    }

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, message: 'Token expired.', code: 'TOKEN_EXPIRED' });
    }
    return res.status(401).json({ success: false, message: 'Invalid token.' });
  }
};

// ─── Role-Based Access Control ───────────────────────────────────────────────
// Usage: authorize('Admin') or authorize('Admin', 'Department Head')
const authorize = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Not authenticated.' });
    }

    if (!allowedRoles.includes(req.user.role_name)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Required role(s): ${allowedRoles.join(', ')}.`,
      });
    }

    next();
  };
};

module.exports = { authenticate, authorize };
