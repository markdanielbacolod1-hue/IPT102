/**
 * seed.js — Run once to populate roles, departments, and a default admin user.
 * Usage: node seed.js
 */

require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool   = require('./config/db');

const SALT_ROUNDS = 12;

async function seed() {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // ── Roles ────────────────────────────────────────────────────────────────
    const roles = ['Admin', 'Staff', 'Department Head'];
    for (const roleName of roles) {
      await conn.query(
        'INSERT IGNORE INTO roles (role_name) VALUES (?)',
        [roleName]
      );
    }
    console.log('✅  Roles seeded');

    // ── Departments ──────────────────────────────────────────────────────────
    const departments = ['HR', 'Registrar', 'Finance', 'Admin'];
    for (const dept of departments) {
      await conn.query(
        'INSERT IGNORE INTO departments (department_name) VALUES (?)',
        [dept]
      );
    }
    console.log('✅  Departments seeded');

    // ── Default Admin User ───────────────────────────────────────────────────
    const adminEmail    = 'admin@doctrack.local';
    const adminPassword = 'Admin@1234'; // Change immediately after first login!

    const [[existingAdmin]] = await conn.query(
      'SELECT user_id FROM users WHERE email = ?',
      [adminEmail]
    );

    if (!existingAdmin) {
      const [[adminRole]] = await conn.query(
        "SELECT role_id FROM roles WHERE role_name = 'Admin'"
      );
      const [[adminDept]] = await conn.query(
        "SELECT department_id FROM departments WHERE department_name = 'Admin'"
      );

      const hashed = await bcrypt.hash(adminPassword, SALT_ROUNDS);

      await conn.query(
        `INSERT INTO users (full_name, email, password, role_id, department_id, status)
         VALUES ('System Admin', ?, ?, ?, ?, 'Active')`,
        [adminEmail, hashed, adminRole.role_id, adminDept.department_id]
      );

      console.log('✅  Default admin user created');
      console.log(`    Email:    ${adminEmail}`);
      console.log(`    Password: ${adminPassword}`);
      console.log('    ⚠️  Change the password after first login!\n');
    } else {
      console.log('ℹ️   Admin user already exists — skipped');
    }

    // ── Document Categories ──────────────────────────────────────────────────
    const categories = [
      'Transcript Of Records', 'COR', 'Form 137', 'Form 138',
      'Good Moral', 'Grading Sheet', 'Diploma',
    ];
    for (const cat of categories) {
      await conn.query(
        'INSERT IGNORE INTO document_categories (category_name) VALUES (?)',
        [cat]
      );
    }
    console.log('✅  Document categories seeded');

    await conn.commit();
    console.log('\n🎉  Seeding complete!');
  } catch (err) {
    await conn.rollback();
    console.error('❌  Seeding failed:', err);
  } finally {
    conn.release();
    process.exit(0);
  }
}

seed();
