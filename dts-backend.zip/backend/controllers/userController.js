const bcrypt = require('bcryptjs');
const { validationResult } = require('express-validator');
const pool = require('../config/db');

const SALT_ROUNDS = 12;

// ─── GET /api/users  (Admin only) ────────────────────────────────────────────
const getAllUsers = async (req, res) => {
  try {
    const { search, role, department, status, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let where  = ['1=1'];
    let params = [];

    if (search) {
      where.push('(u.full_name LIKE ? OR u.email LIKE ?)');
      params.push(`%${search}%`, `%${search}%`);
    }
    if (role) {
      where.push('r.role_name = ?');
      params.push(role);
    }
    if (department) {
      where.push('d.department_name = ?');
      params.push(department);
    }
    if (status) {
      where.push('u.status = ?');
      params.push(status);
    }

    const whereClause = where.join(' AND ');

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) AS total
       FROM   users u
       JOIN   roles       r ON u.role_id       = r.role_id
       LEFT JOIN departments d ON u.department_id = d.department_id
       WHERE  ${whereClause}`,
      params
    );

    const [users] = await pool.query(
      `SELECT u.user_id, u.full_name, u.email, u.status, u.created_at,
              r.role_name, d.department_name
       FROM   users u
       JOIN   roles       r ON u.role_id       = r.role_id
       LEFT JOIN departments d ON u.department_id = d.department_id
       WHERE  ${whereClause}
       ORDER  BY u.created_at DESC
       LIMIT  ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    return res.status(200).json({
      success: true,
      data:    users,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    console.error('getAllUsers error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── GET /api/users/:id ───────────────────────────────────────────────────────
const getUserById = async (req, res) => {
  try {
    const { id } = req.params;

    // Staff can only view their own profile
    if (req.user.role_name === 'Staff' && parseInt(id) !== req.user.user_id) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const [rows] = await pool.query(
      `SELECT u.user_id, u.full_name, u.email, u.status, u.created_at,
              r.role_id, r.role_name, d.department_id, d.department_name
       FROM   users u
       JOIN   roles       r ON u.role_id       = r.role_id
       LEFT JOIN departments d ON u.department_id = d.department_id
       WHERE  u.user_id = ?`,
      [id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    return res.status(200).json({ success: true, data: rows[0] });
  } catch (err) {
    console.error('getUserById error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── POST /api/users  (Admin only) ───────────────────────────────────────────
const createUser = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, errors: errors.array() });
    }

    const { full_name, email, password, role_id, department_id, status = 'Active' } = req.body;

    // Check email uniqueness
    const [existing] = await pool.query('SELECT user_id FROM users WHERE email = ?', [email.toLowerCase()]);
    if (existing.length) {
      return res.status(409).json({ success: false, message: 'Email is already registered.' });
    }

    // Validate role_id exists
    const [role] = await pool.query('SELECT role_id FROM roles WHERE role_id = ?', [role_id]);
    if (!role.length) {
      return res.status(400).json({ success: false, message: 'Invalid role.' });
    }

    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    const [result] = await pool.query(
      `INSERT INTO users (full_name, email, password, role_id, department_id, status)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [full_name.trim(), email.trim().toLowerCase(), hashedPassword, role_id, department_id || null, status]
    );

    return res.status(201).json({
      success: true,
      message: 'User created successfully.',
      data: { userId: result.insertId },
    });
  } catch (err) {
    console.error('createUser error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── PUT /api/users/:id  (Admin, or own profile for Staff/Dept Head) ─────────
const updateUser = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, errors: errors.array() });
    }

    const { id } = req.params;
    const isSelf  = parseInt(id) === req.user.user_id;
    const isAdmin = req.user.role_name === 'Admin';

    // Non-admins may only update their own profile and cannot change role/status
    if (!isAdmin && !isSelf) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const [existing] = await pool.query('SELECT * FROM users WHERE user_id = ?', [id]);
    if (!existing.length) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    const current = existing[0];
    const {
      full_name    = current.full_name,
      email        = current.email,
      role_id      = current.role_id,
      department_id = current.department_id,
      status       = current.status,
    } = req.body;

    // Prevent non-admins from changing their role or status
    const finalRoleId = isAdmin ? role_id : current.role_id;
    const finalStatus = isAdmin ? status  : current.status;

    // Email uniqueness check (ignore self)
    const [emailCheck] = await pool.query(
      'SELECT user_id FROM users WHERE email = ? AND user_id != ?',
      [email.toLowerCase(), id]
    );
    if (emailCheck.length) {
      return res.status(409).json({ success: false, message: 'Email already used by another account.' });
    }

    await pool.query(
      `UPDATE users SET full_name = ?, email = ?, role_id = ?, department_id = ?, status = ?
       WHERE  user_id = ?`,
      [full_name.trim(), email.trim().toLowerCase(), finalRoleId, department_id, finalStatus, id]
    );

    return res.status(200).json({ success: true, message: 'User updated successfully.' });
  } catch (err) {
    console.error('updateUser error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── PATCH /api/users/:id/password ───────────────────────────────────────────
const changePassword = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, errors: errors.array() });
    }

    const { id } = req.params;
    const isAdmin = req.user.role_name === 'Admin';
    const isSelf  = parseInt(id) === req.user.user_id;

    if (!isAdmin && !isSelf) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const { currentPassword, newPassword } = req.body;

    const [rows] = await pool.query('SELECT password FROM users WHERE user_id = ?', [id]);
    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    // Non-admins must verify current password; admins can reset directly
    if (!isAdmin) {
      const match = await bcrypt.compare(currentPassword, rows[0].password);
      if (!match) {
        return res.status(401).json({ success: false, message: 'Current password is incorrect.' });
      }
    }

    const hashed = await bcrypt.hash(newPassword, SALT_ROUNDS);
    await pool.query('UPDATE users SET password = ? WHERE user_id = ?', [hashed, id]);

    return res.status(200).json({ success: true, message: 'Password updated successfully.' });
  } catch (err) {
    console.error('changePassword error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── PATCH /api/users/:id/status  (Admin only) ───────────────────────────────
const toggleUserStatus = async (req, res) => {
  try {
    const { id } = req.params;

    // Cannot deactivate yourself
    if (parseInt(id) === req.user.user_id) {
      return res.status(400).json({ success: false, message: 'Cannot change your own account status.' });
    }

    const [rows] = await pool.query('SELECT status FROM users WHERE user_id = ?', [id]);
    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    const newStatus = rows[0].status === 'Active' ? 'Inactive' : 'Active';
    await pool.query('UPDATE users SET status = ? WHERE user_id = ?', [newStatus, id]);

    return res.status(200).json({
      success: true,
      message: `User ${newStatus === 'Active' ? 'activated' : 'deactivated'} successfully.`,
      data: { status: newStatus },
    });
  } catch (err) {
    console.error('toggleUserStatus error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── DELETE /api/users/:id  (Admin only) ─────────────────────────────────────
const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;

    if (parseInt(id) === req.user.user_id) {
      return res.status(400).json({ success: false, message: 'Cannot delete your own account.' });
    }

    const [rows] = await pool.query('SELECT user_id FROM users WHERE user_id = ?', [id]);
    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    // Soft delete: set status to Inactive instead of hard delete to preserve audit trail
    await pool.query("UPDATE users SET status = 'Inactive' WHERE user_id = ?", [id]);

    return res.status(200).json({ success: true, message: 'User deleted (deactivated) successfully.' });
  } catch (err) {
    console.error('deleteUser error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── GET /api/users/:id/activity ─────────────────────────────────────────────
const getUserActivity = async (req, res) => {
  try {
    const { id } = req.params;
    const { limit = 20, page = 1 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    const isSelf  = parseInt(id) === req.user.user_id;
    const isAdmin = req.user.role_name === 'Admin';

    if (!isAdmin && !isSelf) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const [logs] = await pool.query(
      `SELECT log_id, activity, activity_time, status
       FROM   user_activity_logs
       WHERE  user_id = ?
       ORDER  BY activity_time DESC
       LIMIT  ? OFFSET ?`,
      [id, parseInt(limit), offset]
    );

    return res.status(200).json({ success: true, data: logs });
  } catch (err) {
    console.error('getUserActivity error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── GET /api/roles ───────────────────────────────────────────────────────────
const getRoles = async (req, res) => {
  try {
    const [roles] = await pool.query('SELECT role_id, role_name FROM roles ORDER BY role_name');
    return res.status(200).json({ success: true, data: roles });
  } catch (err) {
    console.error('getRoles error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── GET /api/departments ─────────────────────────────────────────────────────
const getDepartments = async (req, res) => {
  try {
    const [depts] = await pool.query('SELECT department_id, department_name FROM departments ORDER BY department_name');
    return res.status(200).json({ success: true, data: depts });
  } catch (err) {
    console.error('getDepartments error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

module.exports = {
  getAllUsers,
  getUserById,
  createUser,
  updateUser,
  changePassword,
  toggleUserStatus,
  deleteUser,
  getUserActivity,
  getRoles,
  getDepartments,
};
