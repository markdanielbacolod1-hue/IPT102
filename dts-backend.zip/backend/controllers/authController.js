const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const pool   = require('../config/db');

// ─── Helpers ─────────────────────────────────────────────────────────────────

const generateAccessToken = (userId, role) =>
  jwt.sign({ userId, role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '8h',
  });

const generateRefreshToken = (userId) =>
  jwt.sign({ userId }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  });

const cookieOptions = {
  httpOnly: true,           // Not accessible via JS — prevents XSS theft
  secure:   process.env.NODE_ENV === 'production',
  sameSite: 'lax',
  path:     '/',
};

const logActivity = async (userId, departmentId, activity, status = 'Active') => {
  await pool.query(
    `INSERT INTO user_activity_logs (user_id, activity, department_id, status)
     VALUES (?, ?, ?, ?)`,
    [userId, activity, departmentId, status]
  );
};

// ─── POST /api/auth/login ─────────────────────────────────────────────────────
const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }

    // Fetch user with role
    const [rows] = await pool.query(
      `SELECT u.user_id, u.full_name, u.email, u.password, u.status,
              u.department_id, r.role_name
       FROM   users u
       JOIN   roles r ON u.role_id = r.role_id
       WHERE  u.email = ?`,
      [email.trim().toLowerCase()]
    );

    if (!rows.length) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const user = rows[0];

    if (user.status !== 'Active') {
      return res.status(403).json({ success: false, message: 'Account is inactive. Contact your administrator.' });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    // Issue tokens
    const accessToken  = generateAccessToken(user.user_id, user.role_name);
    const refreshToken = generateRefreshToken(user.user_id);

    // Set tokens as httpOnly cookies
    res.cookie('accessToken',  accessToken,  { ...cookieOptions, maxAge: 8 * 60 * 60 * 1000 });       // 8h
    res.cookie('refreshToken', refreshToken, { ...cookieOptions, maxAge: 7 * 24 * 60 * 60 * 1000 }); // 7d

    await logActivity(user.user_id, user.department_id, 'Login Successful');

    return res.status(200).json({
      success: true,
      message: 'Login successful.',
      user: {
        userId:     user.user_id,
        fullName:   user.full_name,
        email:      user.email,
        role:       user.role_name,
        departmentId: user.department_id,
      },
      // Also return access token in body for SPA clients that prefer header auth
      accessToken,
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── POST /api/auth/logout ────────────────────────────────────────────────────
const logout = async (req, res) => {
  try {
    if (req.user) {
      await logActivity(req.user.user_id, req.user.department_id, 'Logged Out');
    }

    res.clearCookie('accessToken',  { ...cookieOptions });
    res.clearCookie('refreshToken', { ...cookieOptions });

    return res.status(200).json({ success: true, message: 'Logged out successfully.' });
  } catch (err) {
    console.error('Logout error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── POST /api/auth/refresh ───────────────────────────────────────────────────
const refreshToken = async (req, res) => {
  try {
    const token = req.cookies?.refreshToken;

    if (!token) {
      return res.status(401).json({ success: false, message: 'Refresh token required.' });
    }

    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_REFRESH_SECRET);
    } catch {
      res.clearCookie('refreshToken', cookieOptions);
      return res.status(401).json({ success: false, message: 'Invalid or expired refresh token.' });
    }

    // Re-fetch user to ensure they're still active
    const [rows] = await pool.query(
      `SELECT u.user_id, u.status, r.role_name, u.department_id
       FROM   users u
       JOIN   roles r ON u.role_id = r.role_id
       WHERE  u.user_id = ?`,
      [decoded.userId]
    );

    if (!rows.length || rows[0].status !== 'Active') {
      return res.status(403).json({ success: false, message: 'User account is inactive.' });
    }

    const user = rows[0];
    const newAccessToken = generateAccessToken(user.user_id, user.role_name);

    res.cookie('accessToken', newAccessToken, { ...cookieOptions, maxAge: 8 * 60 * 60 * 1000 });

    return res.status(200).json({
      success: true,
      accessToken: newAccessToken,
    });
  } catch (err) {
    console.error('Refresh token error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

// ─── GET /api/auth/me ─────────────────────────────────────────────────────────
const getMe = async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT u.user_id, u.full_name, u.email, u.status,
              r.role_name, d.department_name, u.created_at
       FROM   users u
       JOIN   roles r       ON u.role_id       = r.role_id
       LEFT JOIN departments d ON u.department_id = d.department_id
       WHERE  u.user_id = ?`,
      [req.user.user_id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    return res.status(200).json({ success: true, user: rows[0] });
  } catch (err) {
    console.error('GetMe error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
};

module.exports = { login, logout, refreshToken, getMe };
